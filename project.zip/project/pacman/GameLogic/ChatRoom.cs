﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pacman.GameLogic
{
    public class ChatRoom
    {
        private List<string> messages;
        private string username;

        public ChatRoom(string userName)
        {

        }
        
    }
}

﻿namespace pacman
{
    public class VectorDependencies
    {
        public int Index { get; set; }
        public int Version { get; set; }
    }
}